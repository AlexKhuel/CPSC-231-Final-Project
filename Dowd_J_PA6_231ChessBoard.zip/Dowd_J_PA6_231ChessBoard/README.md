Information

-   Chess Game
-   CPSC-231-01
-   PA6 ;Chess Boadr

Sources

-   Bishop.java
-   Board.java
-   BorderLayoutExample.java
-   chessBoard.java
-   King.java
-   Knight.java
-   Pawn.java
-   Piece.java
-   Queen.java
-   Rook.java

Runtime Issues

-   None Known

References:
_ Joshua and Nate debugged (Fixed implementation of other classes, tested various positions, created extra functions, rewrote basically everything)
_ Joshua wrote the board class
_ Nate wrote the pawn class and the GUI
_ Jerry wrote the king class
_ Jake wrote the bishop, rook, knight, and queen classes
_ Jake wrote the writeup
_ Jake wrote the headers for the files
_ GUI was written with claude code. Specifically BorderLayoutExample.java and most of chessBoard.java
\_ Claude also helped with writing JavaDocs

Instructions
_ javac \*.java
_ java BorderLayoutExample

Our write-up:
https://docs.google.com/document/d/1hqBZeXH0tDGQt25YnvoQm2VCV-nUeOmukbo8bMKE9aE/edit?tab=t.0
